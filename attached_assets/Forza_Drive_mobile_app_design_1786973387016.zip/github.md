repo: nffcdan23/Drive-OS
branch: main
path: artifacts/mobile

## Last sync

date: 2026-08-12T21:30:00Z

### Updated in this project

- Recreated the current Expo build (Map, Journeys, Garage, Profile) as an empty-account prototype
- Added two DriveOS visual directions — light with a hand-built vector map, and dark with a placeholder map surface
- Swapped Inter for Archivo (expanded numerals) in the redesign only; recreation keeps Inter

## Screen map

| Project screen | Repo files |
|---|---|
| 1a Map | app/(tabs)/index.tsx, constants/colors.ts, constants/config.ts |
| 1a Journeys | app/(tabs)/journeys.tsx, lib/units.ts |
| 1a Garage | app/(tabs)/garage.tsx, components/EmptyState.tsx |
| 1a Profile | app/(tabs)/profile.tsx, context/AppContext.tsx (default profile), constants/mockData.ts (achievements) |
| Tab bar (all) | app/(tabs)/_layout.tsx |
| 1b / 1c redesign | same source screens, restyled |
